/**
 * CloudVault - Secure Cloud-Based File Storage and Collaboration Application
 * CSA1515 - Cloud Computing and Big Data Analytics - Group Assignment
 *
 * This server exposes a REST (Web API) backend that a browser-based
 * front end talks to. Two storage adapters are provided:
 *   1. LocalDiskAdapter   -> used for local demonstration/testing
 *   2. AwsS3Adapter       -> used when deployed to AWS (real cloud storage)
 * The active adapter is chosen with the STORAGE_DRIVER environment
 * variable, so the same API layer works unchanged in both cases.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'demo-secret-change-in-production';
const STORAGE_DRIVER = process.env.STORAGE_DRIVER || 'local';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---------------------------------------------------------------------------
// "Database" layer (JSON file used to keep the demo self-contained; in the
// deployed version this would be Amazon RDS / DynamoDB).
// ---------------------------------------------------------------------------
const DB_FILE = path.join(__dirname, 'db.json');
function readDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], files: [], shares: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
}
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ---------------------------------------------------------------------------
// Storage adapters (Strategy pattern) - lets the app "communicate with
// cloud services" without hard-coding a single provider.
// ---------------------------------------------------------------------------
class LocalDiskAdapter {
  constructor() {
    this.root = path.join(__dirname, 'storage');
    if (!fs.existsSync(this.root)) fs.mkdirSync(this.root, { recursive: true });
  }
  async save(key, buffer) {
    fs.writeFileSync(path.join(this.root, key), buffer);
    return { key, location: `local://${key}` };
  }
  async load(key) {
    return fs.readFileSync(path.join(this.root, key));
  }
  async remove(key) {
    const p = path.join(this.root, key);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

// Real AWS S3 adapter - used automatically when STORAGE_DRIVER=s3 and AWS
// credentials are supplied (via environment variables / IAM role). Requires
// the "@aws-sdk/client-s3" package: npm install @aws-sdk/client-s3
class AwsS3Adapter {
  constructor() {
    const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
    this.client = new S3Client({ region: process.env.AWS_REGION || 'ap-south-1' });
    this.bucket = process.env.S3_BUCKET;
    this.PutObjectCommand = PutObjectCommand;
    this.GetObjectCommand = GetObjectCommand;
    this.DeleteObjectCommand = DeleteObjectCommand;
  }
  async save(key, buffer) {
    await this.client.send(new this.PutObjectCommand({ Bucket: this.bucket, Key: key, Body: buffer }));
    return { key, location: `s3://${this.bucket}/${key}` };
  }
  async load(key) {
    const res = await this.client.send(new this.GetObjectCommand({ Bucket: this.bucket, Key: key }));
    return res.Body;
  }
  async remove(key) {
    await this.client.send(new this.DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }
}

const storage = STORAGE_DRIVER === 's3' ? new AwsS3Adapter() : new LocalDiskAdapter();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

// ---------------------------------------------------------------------------
// Auth middleware
// ---------------------------------------------------------------------------
function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Missing authorization header' });
  const token = header.replace('Bearer ', '');
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// ---------------------------------------------------------------------------
// Auth endpoints
// ---------------------------------------------------------------------------
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email and password are required' });
  const db = readDB();
  if (db.users.find(u => u.email === email)) return res.status(409).json({ error: 'Account already exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: uuidv4(), name, email, password: hash, createdAt: new Date().toISOString() };
  db.users.push(user);
  writeDB(db);
  res.status(201).json({ message: 'Account created successfully' });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(401).json({ error: 'Invalid email or password' });
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ error: 'Invalid email or password' });
  const token = jwt.sign({ id: user.id, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: '2h' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

// ---------------------------------------------------------------------------
// File endpoints (all protected by JWT authentication)
// ---------------------------------------------------------------------------
app.post('/api/files', authenticate, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file supplied' });
  const db = readDB();
  const key = `${uuidv4()}-${req.file.originalname}`;
  await storage.save(key, req.file.buffer);
  const record = {
    id: uuidv4(),
    key,
    name: req.file.originalname,
    size: req.file.size,
    mimeType: req.file.mimetype,
    ownerId: req.user.id,
    uploadedAt: new Date().toISOString(),
  };
  db.files.push(record);
  writeDB(db);
  res.status(201).json(record);
});

app.get('/api/files', authenticate, (req, res) => {
  const db = readDB();
  const owned = db.files.filter(f => f.ownerId === req.user.id);
  const sharedWithMe = db.shares
    .filter(s => s.sharedWithEmail === req.user.email)
    .map(s => ({ ...db.files.find(f => f.id === s.fileId), permission: s.permission, sharedBy: s.ownerEmail }))
    .filter(f => f.id);
  res.json({ owned, sharedWithMe });
});

app.get('/api/files/:id/download', authenticate, async (req, res) => {
  const db = readDB();
  const file = db.files.find(f => f.id === req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  const isOwner = file.ownerId === req.user.id;
  const isShared = db.shares.find(s => s.fileId === file.id && s.sharedWithEmail === req.user.email);
  if (!isOwner && !isShared) return res.status(403).json({ error: 'Access denied' });
  const buffer = await storage.load(file.key);
  res.setHeader('Content-Disposition', `attachment; filename="${file.name}"`);
  res.send(buffer);
});

app.delete('/api/files/:id', authenticate, async (req, res) => {
  const db = readDB();
  const file = db.files.find(f => f.id === req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  if (file.ownerId !== req.user.id) return res.status(403).json({ error: 'Only the owner can delete this file' });
  await storage.remove(file.key);
  db.files = db.files.filter(f => f.id !== file.id);
  db.shares = db.shares.filter(s => s.fileId !== file.id);
  writeDB(db);
  res.json({ message: 'File deleted' });
});

app.post('/api/files/:id/share', authenticate, (req, res) => {
  const { email, permission } = req.body; // permission: 'view' | 'edit'
  const db = readDB();
  const file = db.files.find(f => f.id === req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  if (file.ownerId !== req.user.id) return res.status(403).json({ error: 'Only the owner can share this file' });
  db.shares.push({ id: uuidv4(), fileId: file.id, sharedWithEmail: email, ownerEmail: req.user.email, permission: permission || 'view', sharedAt: new Date().toISOString() });
  writeDB(db);
  res.status(201).json({ message: `File shared with ${email}` });
});

app.get('/api/health', (req, res) => res.json({ status: 'ok', storageDriver: STORAGE_DRIVER }));

app.listen(PORT, () => console.log(`CloudVault API listening on port ${PORT} (storage driver: ${STORAGE_DRIVER})`));
