# CloudVault — Secure Cloud-Based File Storage & Collaboration Application
CSA1515 — Cloud Computing and Big Data Analytics — Group Assignment
Kanishk C | 192511278

## What this is
A working prototype REST API + browser front end for secure file
upload, download, sharing and management, built for the CSA1515
assignment. See the accompanying Word report for full design,
algorithms, test cases and analysis.

## Folder structure
```
cloudvault/
├── server/
│   ├── server.js        -> Express REST API (auth, files, sharing)
│   └── package.json     -> dependencies
├── public/               -> Browser front end (static HTML/CSS)
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   └── style.css
└── README.md
```

## Running locally (demo mode — local disk storage)
```bash
cd server
npm install
node server.js
```
The API starts on http://localhost:4000 and serves the front end
from the public/ folder at the same address. Open
http://localhost:4000/login.html in a browser.

## Running against real Amazon S3 (production mode)
1. Install the AWS SDK: `npm install @aws-sdk/client-s3`
2. Create an S3 bucket and an IAM user/role with PutObject,
   GetObject and DeleteObject permissions scoped to that bucket.
3. Set environment variables before starting the server:
   ```bash
   export STORAGE_DRIVER=s3
   export AWS_REGION=ap-south-1
   export S3_BUCKET=your-bucket-name
   export AWS_ACCESS_KEY_ID=...
   export AWS_SECRET_ACCESS_KEY=...
   node server.js
   ```
No code changes are needed — the storage adapter is chosen
automatically based on STORAGE_DRIVER.

## Key REST endpoints
| Method | Endpoint                  | Description                          |
|--------|----------------------------|---------------------------------------|
| POST   | /api/auth/register         | Create an account                     |
| POST   | /api/auth/login             | Log in, returns a JWT                 |
| POST   | /api/files                  | Upload a file (multipart, auth req'd) |
| GET    | /api/files                  | List owned + shared-with-me files     |
| GET    | /api/files/:id/download      | Download a file you own or were shared|
| POST   | /api/files/:id/share         | Share a file (owner only)             |
| DELETE | /api/files/:id               | Delete a file (owner only)            |
| GET    | /api/health                  | Health check                          |

## Quick test with curl
```bash
# Register
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Kanishk C","email":"kanishk@cloudvault.com","password":"Secure@123"}'

# Login (copy the token from the response)
curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"kanishk@cloudvault.com","password":"Secure@123"}'

# Upload a file
curl -X POST http://localhost:4000/api/files \
  -H "Authorization: Bearer <token>" \
  -F "file=@/path/to/file.txt"
```

## Security notes
- Passwords are hashed with bcrypt (never stored in plain text).
- Sessions are stateless JSON Web Tokens (2-hour expiry).
- Every file route checks ownership or an explicit share record
  before serving, modifying, or deleting anything.
